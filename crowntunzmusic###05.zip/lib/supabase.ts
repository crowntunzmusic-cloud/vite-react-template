'use client';

import { mockTracks } from './mock-data';

// Custom in-memory storage for SSR and fallback
const memoryDb: Record<string, any[]> = {};

// Check if localStorage is available
const isBrowser = typeof window !== 'undefined';

// Safe localStorage accessors
function getStorageItem(key: string): string | null {
  if (!isBrowser) return null;
  try {
    return localStorage.getItem(key);
  } catch (e) {
    console.error('Error reading localStorage', e);
    return null;
  }
}

function setStorageItem(key: string, value: string): void {
  if (!isBrowser) return;
  try {
    localStorage.setItem(key, value);
  } catch (e) {
    console.error('Error writing localStorage', e);
  }
}

// Initial seed data for our tables
const FEATURE_KEYS = [
  'beats', 'songs', 'uploads', 'lyrics', 'analytics', 'revenue',
  'followers', 'promotions', 'distribution', 'playlists', 'messages',
  'comments', 'collaborations', 'notifications', 'lyrics_tool', 'radio'
];

const SEED_DATA: Record<string, any[]> = {
  tracks: mockTracks.map(t => ({
    ...t,
    is_beat: t.genre === 'Synthwave',
    bpm: t.genre === 'Synthwave' ? 120 : undefined,
    key_signature: 'C Minor',
    license: 'Non-Exclusive',
    owner_id: '00000000-0000-0000-0000-000000000002'
  })),
  user_profiles: [
    {
      id: '00000000-0000-0000-0000-000000000002',
      email: 'studio@crowntunz.fm',
      display_name: 'CrownTunz Studio',
      role: 'producer',
      is_disabled: false,
      avatar_url: 'https://api.dicebear.com/7.x/bottts/svg?seed=crowntunz',
      joined_at: '2026-01-01T00:00:00.000Z'
    },
    {
      id: '00000000-0000-0000-0000-000000000003',
      email: 'newwebhack@gmail.com',
      display_name: 'Main Admin',
      role: 'super_admin',
      is_disabled: false,
      avatar_url: 'https://api.dicebear.com/7.x/bottts/svg?seed=admin',
      joined_at: '2026-01-01T00:00:00.000Z'
    }
  ],
  feature_flags: FEATURE_KEYS.map(key => ({
    feature_key: key,
    label: key.charAt(0).toUpperCase() + key.slice(1).replace('_', ' '),
    description: `Access to the ${key} section of the platform.`,
    category: key === 'beats' || key === 'songs' || key === 'uploads' ? 'catalog' : 'general',
    is_enabled: true,
    updated_at: new Date().toISOString()
  })),
  platform_settings: [
    {
      id: '00000000-0000-0000-0000-000000000001',
      lyric_upload_tier: 'premium',
      max_upload_size: 50 * 1024 * 1024,
      updated_by: 'super_admin',
      updated_at: new Date().toISOString()
    }
  ],
  beats: [
    {
      id: 'b1',
      track_id: 'c10a3f9a-1b2c-4d3e-8a9f-1c2d3e4f5a01',
      producer: 'Lunar Echo',
      price_cents: 2999,
      genre: 'Synthwave',
      is_exclusive: false,
      plays: 142,
      created_at: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'b2',
      track_id: 'c10a3f9a-1b2c-4d3e-8a9f-1c2d3e4f5a02',
      producer: 'Lunar Echo',
      price_cents: 4999,
      genre: 'Synthwave',
      is_exclusive: true,
      plays: 89,
      created_at: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString()
    }
  ],
  revenue: [
    {
      id: 'r1',
      track_id: 'c10a3f9a-1b2c-4d3e-8a9f-1c2d3e4f5a01',
      source: 'Spotify Streaming',
      amount_cents: 14250,
      currency: 'USD',
      occurred_at: new Date(Date.now() - 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'r2',
      track_id: 'c10a3f9a-1b2c-4d3e-8a9f-1c2d3e4f5a02',
      source: 'Apple Music',
      amount_cents: 8900,
      currency: 'USD',
      occurred_at: new Date(Date.now() - 48 * 3600 * 1000).toISOString()
    },
    {
      id: 'r3',
      track_id: 'c10a3f9a-1b2c-4d3e-8a9f-1c2d3e4f5a01',
      source: 'Direct License',
      amount_cents: 2999,
      currency: 'USD',
      occurred_at: new Date(Date.now() - 12 * 3600 * 1000).toISOString()
    }
  ],
  comments: [
    {
      id: 'comm-1',
      track_id: 'c10a3f9a-1b2c-4d3e-8a9f-1c2d3e4f5a01',
      author: 'MelodySeeker',
      body: 'This track is an absolute masterpiece! Loving the retro synth vibe.',
      created_at: new Date(Date.now() - 36 * 3600 * 1000).toISOString()
    }
  ],
  notifications: [
    {
      id: 'notif-1',
      category: 'system',
      title: 'Welcome to CrownTunz',
      body: 'Get started by exploring the dashboard, managing beats, and setting up features.',
      read_at: null,
      created_at: new Date().toISOString()
    }
  ],
  followers: [
    {
      id: 'f1',
      handle: 'beatmaker_fan',
      display_name: 'Beatmaker Fan',
      avatar_url: 'https://api.dicebear.com/7.x/bottts/svg?seed=fan1',
      followed_at: new Date().toISOString()
    }
  ],
  admin_audit_log: [],
  generated_lyrics: [],
  help_tickets: [],
  track_submissions: [],
  uploads: [],
  promotions: [],
  distribution: [],
  collaborations: [],
  messages: []
};

// Database helper functions
function getTableData(table: string): any[] {
  const key = `crowntunz_db_${table}`;
  const localData = getStorageItem(key);
  if (localData) {
    try {
      return JSON.parse(localData);
    } catch (e) {
      console.error('Error parsing storage for table ' + table, e);
    }
  }

  // Use seed or memory fallback
  if (!memoryDb[table]) {
    memoryDb[table] = SEED_DATA[table] ? [...SEED_DATA[table]] : [];
  }
  return memoryDb[table];
}

function saveTableData(table: string, data: any[]): void {
  const key = `crowntunz_db_${table}`;
  setStorageItem(key, JSON.stringify(data));
  memoryDb[table] = data;
}

class QueryBuilder {
  private table: string;
  private action: 'select' | 'insert' | 'update' | 'delete' = 'select';
  private payload: any = null;
  private filters: Array<{ col: string; val: any; operator: 'eq' | 'neq' | 'in' }> = [];
  private orderByCol: string | null = null;
  private orderByAscending = true;
  private limitCount: number | null = null;
  private isSingle = false;
  private isMaybeSingle = false;

  constructor(table: string) {
    this.table = table;
  }

  select(columns?: string) {
    this.action = 'select';
    return this;
  }

  insert(data: any) {
    this.action = 'insert';
    this.payload = data;
    return this;
  }

  update(data: any) {
    this.action = 'update';
    this.payload = data;
    return this;
  }

  delete() {
    this.action = 'delete';
    return this;
  }

  eq(col: string, val: any) {
    this.filters.push({ col, val, operator: 'eq' });
    return this;
  }

  neq(col: string, val: any) {
    this.filters.push({ col, val, operator: 'neq' });
    return this;
  }

  in(col: string, val: any[]) {
    this.filters.push({ col, val, operator: 'in' });
    return this;
  }

  is(col: string, val: any) {
    this.filters.push({ col, val, operator: 'eq' });
    return this;
  }

  order(col: string, options?: { ascending?: boolean; nullsFirst?: boolean }) {
    this.orderByCol = col;
    this.orderByAscending = options?.ascending !== false;
    return this;
  }

  limit(num: number) {
    this.limitCount = num;
    return this;
  }

  single() {
    this.isSingle = true;
    this.isMaybeSingle = false;
    return this;
  }

  maybeSingle() {
    this.isMaybeSingle = true;
    this.isSingle = false;
    return this;
  }

  private matches(row: any): boolean {
    for (const filter of this.filters) {
      if (filter.operator === 'eq') {
        if (String(row[filter.col]) !== String(filter.val)) return false;
      } else if (filter.operator === 'neq') {
        if (String(row[filter.col]) === String(filter.val)) return false;
      } else if (filter.operator === 'in') {
        const arr = Array.isArray(filter.val) ? filter.val : [filter.val];
        if (!arr.map(String).includes(String(row[filter.col]))) return false;
      }
    }
    return true;
  }

  private execute() {
    let rows = [...getTableData(this.table)];

    if (this.action === 'select') {
      // Filter rows
      rows = rows.filter(row => this.matches(row));

      // Order rows
      if (this.orderByCol) {
        const col = this.orderByCol;
        const asc = this.orderByAscending;
        rows.sort((a, b) => {
          const valA = a[col];
          const valB = b[col];
          if (valA === undefined || valA === null) return asc ? -1 : 1;
          if (valB === undefined || valB === null) return asc ? 1 : -1;
          if (valA < valB) return asc ? -1 : 1;
          if (valA > valB) return asc ? 1 : -1;
          return 0;
        });
      }

      // Limit rows
      if (this.limitCount !== null) {
        rows = rows.slice(0, this.limitCount);
      }

      if (this.isSingle) {
        return { data: rows[0] || null, error: rows.length === 0 ? new Error('No rows found') : null };
      }
      if (this.isMaybeSingle) {
        return { data: rows[0] || null, error: null };
      }

      return { data: rows, error: null };
    }

    if (this.action === 'insert') {
      const itemsToInsert = Array.isArray(this.payload) ? this.payload : [this.payload];
      const inserted: any[] = [];

      for (const item of itemsToInsert) {
        const newItem = {
          id: item.id || crypto.randomUUID(),
          created_at: item.created_at || new Date().toISOString(),
          ...item
        };
        rows.push(newItem);
        inserted.push(newItem);
      }

      saveTableData(this.table, rows);

      const returned = Array.isArray(this.payload) ? inserted : inserted[0];
      return { data: returned, error: null };
    }

    if (this.action === 'update') {
      // Find matching items to update
      rows = rows.map(row => {
        if (this.matches(row)) {
          return { ...row, ...this.payload };
        }
        return row;
      });

      saveTableData(this.table, rows);

      // Return updated records
      const matched = rows.filter(row => this.matches(row));
      const returned = this.isSingle || this.isMaybeSingle ? matched[0] || null : matched;
      return { data: returned, error: null };
    }

    if (this.action === 'delete') {
      const remaining: any[] = [];
      const deleted: any[] = [];

      for (const row of rows) {
        if (this.matches(row)) {
          deleted.push(row);
        } else {
          remaining.push(row);
        }
      }

      saveTableData(this.table, remaining);

      const returned = this.isSingle || this.isMaybeSingle ? deleted[0] || null : deleted;
      return { data: returned, error: null };
    }

    return { data: null, error: new Error('Unsupported action') };
  }

  // Thenable implementation to support await natively
  then(onfulfilled?: (value: any) => any, onrejected?: (reason: any) => any) {
    const promise = Promise.resolve().then(() => this.execute());
    return promise.then(onfulfilled, onrejected);
  }
}

// Emulate supabase object
export const supabase = {
  auth: {
    signOut: async () => {
      if (isBrowser) {
        // Clear simulated session if desired
      }
      return { error: null };
    },
    getSession: async () => {
      return {
        data: {
          session: {
            user: {
              id: '00000000-0000-0000-0000-000000000003',
              email: 'newwebhack@gmail.com'
            }
          }
        },
        error: null
      };
    },
    onAuthStateChange: (callback: any) => {
      // No-op subscription builder
      return {
        data: {
          subscription: {
            unsubscribe: () => {}
          }
        }
      };
    }
  },
  from: (table: string) => {
    return new QueryBuilder(table);
  }
};
