declare namespace NodeJS {
  interface ProcessEnv {
    NEXT_PUBLIC_CLOUDFLARE_R2_URL?: string;
  }
}

export {};
